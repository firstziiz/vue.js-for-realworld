<template>
    <div class="round">
        <img src="https://lh4.googleusercontent.com/LKym2hemhekop_7ZzJgSltm1Fzjy7R6Z14nEiH-n0h-RGirsEKPXAYleYTxKl8ghxcCgFll0N2JsO-Y=w1366-h638" alt="">
    </div>
</template>

<style>
    .round {
        margin: .6em;
        border-radius: 50%;
        overflow: hidden;
        width: 150px;
        height: 150px;
    }
    .round img {
        display: block;
    /* Stretch 
            height: 100%;
            width: 100%; */
        width: 100%;
        height: 100%;
    }
</style>